import cv2, os
import numpy as np
import glob
import tkinter
from tkinter import *
from tkinter import filedialog
from PIL import Image, ImageTk
root = Tk()
root.title("FACE RECOGNITION")
# Code to add widgets will go here...

# For face detection we will use the Haar Cascade provided by OpenCV.
cascadePath = "haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(cascadePath)

recognizer = cv2.face.LBPHFaceRecognizer_create()
#sizetuple=(320,243)
def get_images_and_labels(path):

    image_paths = [os.path.join(path, f) for f in os.listdir(path) if not f.endswith('.sad')]
    # images will contains face images
    images = []
    # labels will contains the label that is assigned to the image
    labels = []
    for image_path in image_paths:
        # Read the image and convert to grayscale
        image_pil = Image.open(image_path).convert('L')

        # Convert the image format into numpy array
        image = np.array(image_pil, 'uint8')
        # Get the label of the image
        nbr = int(os.path.split(image_path)[1].split(".")[0].replace("subject", ""))
        # Detect the face in the image
        faces = faceCascade.detectMultiScale(image,scaleFactor=1.1)
        # If face is detected, append the face to images and the label to labels
        for (x, y, w, h) in faces:
            images.append(image[y: y + 130, x: x + 130])
            labels.append(nbr)
            cv2.imshow("Adding faces to traning set...", image[y: y + 130, x: x + 130])
            cv2.waitKey(40)

    # return the images list and labels list
    return images, labels

# Path to the Yale Dataset
path = './yalefaces'
# Call the get_images_and_labels function and get the face images and the 
# corresponding labels
images, labels = get_images_and_labels(path)
cv2.destroyAllWindows()
recognizer.train(images, np.array(labels))


def helloCallBack():
  # path=filedialog.askopenfilename(filetypes=[("Image File",'.jpg')])
   path = tkinter.filedialog.askopenfilename(
        parent=root, initialdir='C:/Users/hp/Desktop/New folder/yalefaces',
        title='Choose file',
        )
  
   im = Image.open(path)
   g = path[41:50]

   files = glob.glob('./input/*')
   for f in files:
       os.remove(f)
       
   img = np.copy(im)
   cv2.imwrite("./input/"+ g +'.jpg' , img)
   tkimage = ImageTk.PhotoImage(im)
   myvar=Label(root,image = tkimage)
   myvar.image = tkimage
   myvar.pack(padx=100, pady=100, side=TOP)

def show():
    fil = glob.glob('.\input\*')
    for f in fil:
        g = f[8:17]
    cascadePath = "haarcascade_frontalface_default.xml"
    faceCascade = cv2.CascadeClassifier(cascadePath)
    path = './yalefaces'
  # Append the images with the extension .sad into image_paths
    image_paths = [os.path.join(path, f) for f in os.listdir(path) if f.startswith( g )]
    for image_path in image_paths:
       predict_image_pil = Image.open(image_path).convert('L')
       predict_image = np.array(predict_image_pil, 'uint8')
       faces = faceCascade.detectMultiScale(predict_image)
       for (x, y, w, h) in faces:
            cv2.imshow("Recace", predict_image[y: y + 130, x: x + 130])
            cv2.waitKey(1300)
    cv2.destroyAllWindows()


def recog():
    path = './input'
    # Append the images with the extension .sad into image_paths
    image_paths = [os.path.join(path, f) for f in os.listdir(path) ]#if f.endswith('.sad')]
    for image_path in image_paths:
        predict_image_pil = Image.open(image_path).convert('L')
        predict_image = np.array(predict_image_pil, 'uint8')
        faces = faceCascade.detectMultiScale(predict_image)
        image_pil = Image.open(image_path).convert('L')
        image = np.array(image_pil, 'uint8')
    
        for (x, y, w, h) in faces:
        #cv2.imshow("Recace", predict_image[y: y + 130, x: x + 130])
            nbr_predicted, conf = recognizer.predict(predict_image[y: y + 130, x: x + 130])
            nbr_actual = int(os.path.split(image_path)[1].split(".")[0].replace("subject", ""))
            if nbr_actual == nbr_predicted:
                print ("{} is Correctly Recognized with confidence {}".format(nbr_actual, conf))
            else:
                print ("{} is Incorrect Recognized as {}".format(nbr_actual, nbr_predicted))
            cv2.imshow("Recognizing Face", predict_image[y: y + 130, x: x + 130])
            cv2.waitKey(1300)

    cv2.destroyAllWindows()
D= tkinter.Button(root, text ="Similar pics" , command = show )
D.pack(padx=5, pady=5, side=BOTTOM)

C = tkinter.Button(root, text ="Search" , command = recog )
C.pack(padx=5, pady=5, side=BOTTOM)

B = tkinter.Button(root, text ="Select an Image", command = helloCallBack )
B.pack(padx=5, pady=10,side =BOTTOM)



